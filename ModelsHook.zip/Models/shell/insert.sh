#!/bin/sh
dataline=$(cat /home/wwwroot/cwt.auto.cn/storage/app/cmd/names.log)

if [[! -n "$dataline" && "$dataline" == ""]]; then

echo " name is null"

else
    cd /home/wwwroot/www/adverts/$dataline

    php artisan key:generate
    php artisan storage:link
    chown -R  www:www ./*
    chmod -R 777 ./storage
    chmod -R 777 ./storage/
    chmod -R 777 ./storage/*
    chmod -R 777 ./bootstrap/cache/*
    chmod -R 777 ./bootstrap/cache/
    chmod -R 777 ./bootstrap/cache


    mv /home/wwwroot/cwt.auto.cn/storage/app/nginx/$dataline.conf  /usr/local/nginx/conf/vhost/$dataline.conf
    nginx -s reload

    cd /home/wwwroot/cwt.auto.cn/
    chown -R  www:www ./*
fi





