<?php

namespace App\Models;

use App\Model\Model;
use Hyperf\DbConnection\Db;

class GitCheck extends Model
{
    public static $instance;
    const GITUSERNAME = 'tao1442605868:taotao0627';//git用户名：密码
    /**
     * 通过延迟加载（用到时才加载）获取实例
     * @return self
     */
    public static function getInstance()
    {
        if (null === static::$instance) {
            static::$instance = new static();
        }
        return static::$instance;
    }

    /**
     * @param $ids
     * 前台git
     */
    public function foreguound($ids){
        file_put_contents(dirname(__FILE__) . DIRECTORY_SEPARATOR . "./log.txt", date("Y-m-d H:i:s") . "  " . var_export($ids,true) . "\r\n", FILE_APPEND);
        //$ids['repository']['url'] = 'git@code.aliyun.com:nancproject/dedecms.git';
        if(isset($ids['repository']['url'])) {
            $extPath = BASE_PATH;
            if(isset($ids['domain']) && $ids['domain']) {
                $forepath = BASE_PATH.'/'.$ids['domain'];//todo
                $lj = $ids['domain'];
            }else{
                $forepath = BASE_PATH.'/foreground';//todo
                $lj = 'foreground';
            }
            if (is_dir($forepath)) {
                //下拉
                $clonePath = BASE_PATH.'/app/Models/shell/pull.sh';//todo
                $cmd = "{$clonePath} {$forepath} {$ids['checkout_sha']} {$extPath}";//克隆仓库代码到指定文件夹
            } else {
                //克隆
                $getUrl = explode('@',$ids['repository']['url']);
                $rep_url = str_replace(':','/',$getUrl[1]);
                $clone_url = 'https://'.self::GITUSERNAME.'@'.$rep_url;
                $clonePath = BASE_PATH.'/app/Models/shell/fg_clone.sh';//todo
                $pubpath = BASE_PATH;//todo
                $cmd = "{$clonePath} {$pubpath} {$clone_url} {$extPath} {$lj}";//克隆仓库代码到指定文件夹
            }
//            file_put_contents(dirname(__FILE__) . DIRECTORY_SEPARATOR . "./log2.txt", date("Y-m-d H:i:s") . "  " . var_export($cmd,true) . "\r\n", FILE_APPEND);
//            $insert['gid'] = $ids['project_id'];
//            $insert['name'] = $ids['checkout_sha'];
//            $insert['createtime'] = time();
//            Db::table('db_edition')->insertGetId($insert);
            shell_exec($cmd);

            //复制index->resources模板
            $dist = $lj=='foreground'?'dist':$ids['domain'];
            $cpPath = BASE_PATH.'/app/Models/shell/fg_cp.sh';//todo
            $pdpath = BASE_PATH.'/public/'.$dist;//todo
            $respath = BASE_PATH.'/public/view';//todo
            $public = BASE_PATH.'/public';//todo
            $lj = $lj=='foreground'?'index':$ids['domain'];
            $cpcmd = "{$cpPath} {$forepath} {$public} {$pdpath} {$respath} {$extPath} {$lj} {$dist}";//cp文件替换文件
            shell_exec($cpcmd);
            chmod(BASE_PATH,0777);
        }
    }

    /**
     * @param $ids
     * 后台git
     */
    public function background($ids){
        file_put_contents(dirname(__FILE__) . DIRECTORY_SEPARATOR . "./log3.txt", date("Y-m-d H:i:s") . "  " . var_export($ids,true) . "\r\n", FILE_APPEND);
        if(isset($ids['repository']['url'])) {
            $extPath = BASE_PATH;
            $clonePath = BASE_PATH.'/app/Models/shell/pull.sh';//todo
            $basePath = BASE_PATH;
            $cmd = "{$clonePath} {$basePath} {$ids['checkout_sha']} {$extPath}";//克隆仓库代码到指定文件夹
//            file_put_contents(dirname(__FILE__) . DIRECTORY_SEPARATOR . "./log4.txt", date("Y-m-d H:i:s") . "  " . var_export($cmd,true) . "\r\n", FILE_APPEND);

//            $insert['gid'] = $ids['project_id'];
//            $insert['name'] = $ids['checkout_sha'];
//            $insert['createtime'] = time();
//            Db::table('db_edition')->insertGetId($insert);
            shell_exec($cmd);
            //复制index->resources模板
//            $dist = 'dist';
//            $forepath = BASE_PATH.'/foreground';//todo
//            $cpPath = BASE_PATH.'/app/Models/shell/fg_cp.sh';//todo
//            $pdpath = BASE_PATH.'/public/dist';//todo
//            $respath = BASE_PATH.'/public/view';//todo
//            $public = BASE_PATH.'/public';//todo
//            $lj = 'index';
//            $cpcmd = "{$cpPath} {$forepath} {$public} {$pdpath} {$respath} {$extPath} {$lj} {$dist}";//cp文件替换文件
//            shell_exec($cpcmd);
            if(isset($ids['domain']) && $ids['domain']){
                $forepath = BASE_PATH . '/' . $ids['domain'];//todo
                $dist = $ids['domain'];
                $cpPath = BASE_PATH . '/app/Models/shell/fg_cp.sh';//todo
                $pdpath = BASE_PATH . '/public/' . $dist;//todo
                $respath = BASE_PATH . '/public/view';//todo
                $public = BASE_PATH . '/public';//todo
                $cpcmd = "{$cpPath} {$forepath} {$public} {$pdpath} {$respath} {$extPath} {$dist} {$dist}";//cp文件替换文件
                shell_exec($cpcmd);
            }
            chmod(BASE_PATH,0777);
        }
    }
}
