#!/usr/bin/env bash
cd $1;
#pwd;
git fetch && git checkout $2;
git fetch --all;
git reset --hard origin/master;
chmod 777 -R $3/;
chown www:www -R $3/;

