#!/usr/bin/env bash
cd /data/wwwroot/adverts;
#pwd;
#echo $1;
mkdir $1;
cd $1;
#pwd;
git clone $2 ./;

