#!/usr/bin/env bash
cp -rf /data/wwwroot/cwt.auto.cn/storage/app/nginx/test.conf  /usr/local/nginx/conf/vhost/test.conf;
nginx -s reload;

cd /data/wwwroot/adverts;
cd $1;
composer install --ignore-platform-reqs;

cd /data/wwwroot/adverts/$1;

php artisan key:generate;
php artisan storage:link;
chown -R  www:www ./*;
chmod -R 777 ./storage;
chmod -R 777 ./storage/;
chmod -R 777 ./storage/*;
chmod -R 777 ./bootstrap/cache/*;
chmod -R 777 ./bootstrap/cache/;
chmod -R 777 ./bootstrap/cache;

cd /data/wwwroot/cwt.auto.cn/;
chown -R  www:www ./*;
